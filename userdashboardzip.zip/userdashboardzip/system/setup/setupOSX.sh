source ~/.bash_profile
source pylotVenv/bin/activate
